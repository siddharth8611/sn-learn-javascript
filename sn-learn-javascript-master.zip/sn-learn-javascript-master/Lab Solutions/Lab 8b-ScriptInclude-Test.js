//
// Lab 8b Script Include Test Script
//
var list = new SNJS().getRecords('problem', 5);
gs.info(list.length);