//
// L18S01 - Nested loops
//
for (var i = 0; i < 5; i++) {
  for (var j = 0; j < 3; j++) {
    gs.info('i=' + i + ' j=' + j);
  }
}
gs.info('Done i=' + i + ' j=' + j);