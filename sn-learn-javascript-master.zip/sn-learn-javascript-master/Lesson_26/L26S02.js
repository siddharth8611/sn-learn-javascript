//
// L26S02 - Bracket notation…
//
var vehicle = {};
vehicle['year'] = 2018;
vehicle['make'] = "Toyota";
vehicle['model'] = "Sienna";
gs.info(vehicle['year'] + ' ' + vehicle['make'] +  ' ' + vehicle['model']);
