//
// L26S03 - Shortcut - note the double quotes
//
var vehicle = {
  "year" : 2018,
  "make"  : "Toyota",
  "model" : "Sienna"
};
gs.info(vehicle['year'] + ' ' + vehicle['make'] +  ' ' + vehicle['model']);
