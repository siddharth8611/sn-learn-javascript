//
// L16S01 - For loop
//
// Note: break and continue work here too!
for (var i = 0; i < 5; i++) {
  gs.info(i);
}
gs.info('done i=' + i);