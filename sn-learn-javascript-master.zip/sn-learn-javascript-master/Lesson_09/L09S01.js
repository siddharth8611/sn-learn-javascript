//
// L09S01 - Commenting
//

// This is a single line comment

/* This is another way to comment */

/*
 This is a multi-line comment.
 This code is commented out!
 var name = 'Chuck';
 */
gs.info('name = ' + name);
