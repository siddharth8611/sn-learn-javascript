//
// L10S01 - Arithmetic Operators
//
var a = 0;
var b = 1;
gs.info(a < b);

var n = '3';
var i = 3;
gs.info(n == i); // REALLY?!!
gs.info(i = 4); // WATCH OUT!!!