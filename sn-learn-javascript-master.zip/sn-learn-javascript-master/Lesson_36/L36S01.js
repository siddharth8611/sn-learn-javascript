//
// L36S01 - Simple scripted REST API (GET) resource
//
(function process(/*RESTAPIRequest*/ request, /*RESTAPIResponse*/ response) {

  return "hello, world!";
    
})(request, response);