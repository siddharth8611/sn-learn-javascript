//
// L31S01 More string stuff
// Find the position of a character or substring
//
var subject = 'Warning: Email is not working';
var pos = subject.indexOf('Email');
gs.info(pos);